"""Exibe um bitmap 8x8 em uma matriz MAX7219 usando MicroPython no Pico."""

from machine import Pin, SPI
from time import sleep


# Ligações do Raspberry Pi Pico para o módulo MAX7219:
# GP19 -> DIN, GP18 -> CLK, GP17 -> CS, VBUS -> VCC, GND -> GND
spi = SPI(
    0,
    baudrate=1_000_000,
    polarity=0,
    phase=0,
    sck=Pin(18),
    mosi=Pin(19),
)
cs = Pin(17, Pin.OUT, value=1)


# Cada byte representa uma linha da matriz; bit 1 acende o LED.
icone_carregando = (
    0x3C,
    0x7E,
    0xDB,
    0xFF,
    0xFF,
    0x7E,
    0x3C,
    0x18,
)


def escrever_registro(registro, valor):
    """Envia um par endereco/valor ao MAX7219."""
    cs.value(0)
    spi.write(bytes((registro, valor)))
    cs.value(1)


def inicializar_matriz():
    escrever_registro(0x0F, 0x00)  # display test: desligado
    escrever_registro(0x0C, 0x00)  # shutdown: manter em modo desligado
    escrever_registro(0x09, 0x00)  # decode mode: sem decodificacao BCD
    escrever_registro(0x0B, 0x07)  # scan limit: 8 linhas
    escrever_registro(0x0A, 0x04)  # intensidade: 0 a 15

    for linha in range(1, 9):
        escrever_registro(linha, 0x00)

    escrever_registro(0x0C, 0x01)  # sair do shutdown e ligar o visor


def mostrar_icone(bitmap):
    for indice, byte_linha in enumerate(bitmap):
        escrever_registro(indice + 1, byte_linha)


inicializar_matriz()
mostrar_icone(icone_carregando)

while True:
    sleep(1)